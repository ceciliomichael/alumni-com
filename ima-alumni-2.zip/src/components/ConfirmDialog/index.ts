import ConfirmDialog from './ConfirmDialog';
export default ConfirmDialog; 