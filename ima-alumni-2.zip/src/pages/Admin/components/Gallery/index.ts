import GalleryManagement from './GalleryManagement';
import GalleryForm from './GalleryForm';
 
export { GalleryManagement, GalleryForm }; 