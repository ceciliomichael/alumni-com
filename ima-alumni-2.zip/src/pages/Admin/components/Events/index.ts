import EventManagement from './EventManagement';
import EventForm from './EventForm';
 
export { EventManagement, EventForm }; 