export interface Feeling {
  emoji: string;
  text: string;
} 